/*
 * CrossReferenceDispatcher.h
 *
 *  Created on: 17.10.2013
 *      Author: jancajthaml
 */

#ifndef CROSSREFERENCEDISPATCHER_H_
#define CROSSREFERENCEDISPATCHER_H_


//God Fucking Damn you C++

typedef struct { float f1; float f2; float f3;} /*__attribute__((packed))*/ __color;

#include <vector>
#include <list>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <stdio.h>
#include <iostream>
#include <cstdio>
#include <stdint.h>

#include "./../sgl.h"


#endif /* CROSSREFERENCEDISPATCHER_H_ */
